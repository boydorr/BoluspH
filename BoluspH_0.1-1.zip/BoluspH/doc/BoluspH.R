## ---- echo = FALSE, include=FALSE----------------------------------------
set.seed(2018-08-06)

## ---- eval=FALSE---------------------------------------------------------
#  install.packages(c('tidyverse','mgcv','devtools','knitr'))
#  devtools::install_github('boydorr/BoluspH', build_vignettes=TRUE)

## ---- eval=FALSE---------------------------------------------------------
#  vignette('BoluspH', package='BoluspH')

## ------------------------------------------------------------------------
meta <- data.frame(ID=c('Cow_1','Cow_2','Cow_3'), Filename=c('ST1.xlsx','WC1.csv','CS1.csv'), stringsAsFactors=FALSE)

## ------------------------------------------------------------------------
meta <- data.frame(ID=c('Cow_1','Cow_2','Cow_3'), Filename=c('ST1.xlsx','WC1.csv','CS1.csv'), Milking=c('09:00,16:00', '07:00,13:00,18:00', ''), Farm=c('FarmA','FarmB','FarmC'), stringsAsFactors=FALSE)

## ------------------------------------------------------------------------
library('BoluspH')
model <- BoluspH(meta)

## ------------------------------------------------------------------------
testdir <- system.file("extdata", package="BoluspH")
model$AddSmaXtecData(testdir)
model$AddWellCowData(testdir, ID='Cow_2')
model$AddCustomData(testdir, skip=13, date_col=3, time_col=4, pH_col=6, csv=TRUE, sep=';', dec=',', date_format='%d.%m.%Y', time_format='%H:%M')

## ------------------------------------------------------------------------
model$RunModels(gam=TRUE, milking='adjusted')

## ------------------------------------------------------------------------
overview_out <- model$GetOverview()
overview_out

## ------------------------------------------------------------------------
data_out <- model$ExtractData()
str(data_out)
summary(data_out)
head(data_out)

## ------------------------------------------------------------------------
ggplot(data_out, aes(x=Time)) +
	geom_line(mapping=aes(y=pH)) +
	geom_line(mapping=aes(y=prediction), col='blue', lwd=2) +
	facet_wrap(~ID, scale='free')

## ------------------------------------------------------------------------
daily <- data_out %>% group_by(ID, Date) %>%
	summarise(mean_abs_resid = mean(abs(residual)))
head(daily)

ggplot(daily, aes(x=Date, y=mean_abs_resid)) +
	geom_line() +
	facet_wrap(~ID, scales='free_x')

## ------------------------------------------------------------------------
data_ind <- model$ExtractData(ID='Cow_2')
str(data_ind)
summary(data_ind)

write.csv(data_ind, file='Cow_2.csv', row.names=FALSE)

## ------------------------------------------------------------------------
sessionInfo()

